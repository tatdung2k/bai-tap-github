str1 = "        Nguyễn Quốc Chung       "
print (str1.upper())
print(str1, 'Co do dai la:', len(str1))