my_string="hello world"
print("Chiều dài của chuỗi là:", len(my_string))
print(" Sau khi chuyển san in hoa:", my_string.upper())